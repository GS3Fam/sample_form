const electron = require('electron');
const url = require('url');
const path = require('path');
const fs= require('fs');
const file = './form_data/';

var json_files = [];

const{app, BrowserWindow, Menu, ipcMain} = electron;

let mainWindow;
let addWindow;

app.on('ready', function(){
    mainWindow = new BrowserWindow({

    });

    //load html
    mainWindow.loadURL(url.format({
        pathname: path.join(__dirname, 'views/index.html'),
        protocol: 'file',
        slashes: true
    }));

    mainWindow.on('closed', function(){
        app.quit();
    });

    //build menu from template
    const mainMenu = Menu.buildFromTemplate(mainMenuTemplate);
    //Insert menu
    Menu.setApplicationMenu(mainMenu);
});

fs.readdir('../form_data', (err, dir) => {
    //const config_name = require(file + arg);
    // console.log(config_name.columns);
    for (var i = 0, path; path = dir[i]; i++) {
        const config_name = require(file + path);
        const app_name = config_name._app.caption;
        const array = { path, app_name }
        json_files.push(array);
    }
    // console.log(json_files);
    // console.log(json_files);
    ipcMain.on('list_files', (event, arg) => {
        // console.log(arg) // prints "ping"
        event.sender.send('list_files', json_files)
    });
    // mainWindow.webContents.send('list_files', json_files);
});

ipcMain.on('upload-json', (event, arg) => {
    // console.log(arg) // prints "ping"
    // console.log(config);
    const config = require(file + arg);
    // console.log(config);
    // console.log(config);
    // console.log(config._app.caption);
    event.sender.send('upload-json', config)
});

function createNew(){
    // create new window
    addWindow = new BrowserWindow({
        width: 300,
        height: 200,
        title: 'Select File'
    });
    // Load html
    addWindow.loadURL(url.format({
        pathname: path.join(__dirname, 'views/select.html'),
        protocol: 'file',
        slashes: true
    }));
    //Garbage Collection
    addWindow.on('closed', function(){
        addWindow = null;
    });
}

const mainMenuTemplate = [
    {
        label: 'File',
        submenu:[
            {
                label: 'Select File',
                click(){
                    createNew();
                }

            }
        ]
    }
];

// If mac, add empty object
if(process.platform == 'darwin'){
    mainMenuTemplate.unshift({});
}

// add developer tools if not in production
if(process.env.NODE_ENV !== 'production'){
    mainMenuTemplate.push({
        label: 'Developer Tools',
        submenu: [
            {
                label: 'Toogle Devtools',
                accelerator: process.platform == 'darwin' ? 'Command+I' : 'Ctrl+I',
                click(item, focusedWindow){
                    focusedWindow.toggleDevTools();
                }
            },
            {
                role: 'reload'
            }
        ]
    });
}